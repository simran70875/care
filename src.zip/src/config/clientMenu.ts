import { NavItem } from "../layout/AppSidebar";

const reportsSubMenu = [
  { name: "Client Action Summary", path: "/customers/reports/action-summary",},
  { name: "Client Summary PDF", path: "/customers/reports/summary-pdf" },
  { name: "Document List", path: "/customers/reports/documents" },
  { name: "Print Schedule PDF", path: "/customers/reports/print-schedule" },
  { name: "Referral Reports", path: "/customers/reports/referrals" },
  { name: "Future Status Changes", path: "/customers/reports/future-status" },
  { name: "Letters Report", path: "/customers/reports/letters" },
  { name: "Status Change Hrs Affected", path: "/customers/reports/status-hours" },
  { name: "All Client Report", path: "/customers/reports/all" },
]

const outcomeSubMenu = [
  { name: "Outcome Setup", path: "/customers/outcomes/setup" },
  { name: "Tag Setup", path: "/customers/outcomes/tags" },
  { name: "Outcome Overview Report", path: "/customers/outcomes/overview" },
]

const searchSubMenu = [
  { name: "Client Contact Report", path: "/customers/advanced-search/contact" },
  { name: "Client Travel Distance", path: "/customers/advanced-search/travel" },
  { name: "Client/Carer Travel Distance", path: "/customers/advanced-search/travel-both" },
  { name: "Client Tag Setup", path: "/customers/advanced-search/tags" },
  { name: "Plans Taken Report", path: "/customers/advanced-search/plans" },
]

const clientSettingSubMenu = [
  { name: "Assigned Hours", path: "/customers/settings/assigned-hours" },
  { name: "Preferred Carer", path: "/customers/settings/preferred-carer" },
  { name: "Assign Job Types", path: "/customers/settings/job-types" },
  { name: "Assessment Type", path: "/customers/settings/assessment-type" },
  { name: "No Carer Assigned", path: "/customers/settings/no-carer" },
  { name: "Edit Job Types", path: "/customers/settings/edit-job" },
  { name: "Referral Reason Setup", path: "/customers/settings/referral-reason" },
  { name: "Email Schedule", path: "/customers/settings/email-schedule" },
  { name: "Inactive Digital Tasks", path: "/customers/settings/inactive-tasks" },
]

const letterSubMenu = [
  { name: "Completed Templates", path: "/customers/letters/completed" },
  { name: "Template Editor", path: "/customers/letters/editor" },
  { name: "Create Template", path: "/customers/letters/create" },
]

export const clientSubMenu: NavItem[] = [
  { name: "All Clients", path: "/customers/all" },
  { name: "Add Client", path: "/customers/addClient" },
  { name: "Schedule", path: "/customers/schedule" },
  { name: "Reports", path: "/customers/reports", subItems: reportsSubMenu },
  { name: "Outcomes", path: "/customers/outcomes", subItems: outcomeSubMenu },
  { name: "Advanced Search", path: "/customers/advanced-search", subItems: searchSubMenu},
  { name: "Audit Pages", path: "/customers/audit"},
  { name: "Settings", path: "/customers/settings", subItems: clientSettingSubMenu   },
  { name: "Letter Templates", path: "/customers/letters", subItems: letterSubMenu },
];
