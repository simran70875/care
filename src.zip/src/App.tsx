import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ScrollToTop } from "./components/common/ScrollToTop";

import SignIn from "./pages/AuthPages/SignIn";
import NotFound from "./pages/OtherPage/NotFound";
import UserProfiles from "./pages/UserProfiles";
import AppLayout from "./layout/AppLayout";

import Home from "./pages/Dashboard/Home";
import ProductManagement from "./pages/products";
import AgentsPage from "./pages/agents";
import OrdersPage from "./pages/ordersPage";
import QuotationDetailsPage from "./pages/QuotationDetails";
import ReceivedOrders from "./pages/receivedOrders";
import CreateNewOrderPage from "./pages/CreateNewOrderPage";
import ManageCategoriesPage from "./pages/manageCategoriesPage";
import ManageBrandsPage from "./pages/ManageBrandsPage";
import AddProductPage from "./pages/AddProductPage";
import QueriesPage from "./pages/UserQueries";
import EditProductPage from "./pages/EditProduct";
import { Toaster } from "react-hot-toast";
import BannersPage from "./pages/banners";
import FloatingBannerPage from "./pages/floatingBanner";
import LoadingScreen from "./pages/AuthPages/LoadingScreen";
import { useEffect, useState } from "react";
import CustomerPage from "./pages/CustomerPages/Customer";
import AddCustomerPage from "./pages/CustomerPages/AddCustomerPage";
import CustomerDetailsPage from "./pages/CustomerPages/CustomerDetails";
import CustomerDetailsLayout from "./pages/CustomerPages/CustomerDetailsLayout";


export default function App() {
  console.log("i am in development mode now ");

  const [isInitialDataLoading, setIsInitialDataLoading] = useState(true);

  // 1. Simulate initial data fetching or app setup check
  useEffect(() => {
    // Replace with your actual authentication/data loading logic (e.g., API calls)
    const timer = setTimeout(() => {
      setIsInitialDataLoading(false); // After 3 seconds, data is 'loaded'
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <Router>
      <LoadingScreen isAppLoading={isInitialDataLoading}>
        <Toaster
          containerStyle={{ zIndex: 999999999999 }}
          position="top-right"
        />
        <ScrollToTop />
        <Routes>
          {/* Protected Admin Routes */}
          <Route>
            <Route element={<AppLayout />}>
              <Route index path="/" element={<Home />} />
              <Route path="/customers/all" element={<CustomerPage />} />
              <Route path="/customers/addClient" element={<AddCustomerPage />} />
              {/* <Route path="/customers/details" element={<ClientDetailsLayout />}/> */}

              <Route path="/products" element={<ProductManagement />} />
              <Route path="/addProduct" element={<AddProductPage />} />
              <Route path="/editProduct" element={<EditProductPage />} />
              <Route path="/carers" element={<AgentsPage />} />
              <Route path="/quotations" element={<OrdersPage />} />
              <Route path="/quotation-details" element={<QuotationDetailsPage />}/>
              <Route path="/received-orders" element={<ReceivedOrders />} />
              <Route path="/create-order" element={<CreateNewOrderPage />} />
              <Route path="/categories" element={<ManageCategoriesPage />} />
              <Route path="/brands" element={<ManageBrandsPage />} />
              <Route path="/profile" element={<UserProfiles />} />
              <Route path="/queries" element={<QueriesPage />} />
              <Route path="/banners" element={<BannersPage />} />
              <Route path="/floatingBanner" element={<FloatingBannerPage />} />
            </Route>
          </Route>

          <Route element={<CustomerDetailsLayout />}>
             <Route path="/customers/details" element={<CustomerDetailsPage />}/>
          </Route>

          {/* Auth Page */}
          <Route path="/signin" element={<SignIn />} />

          {/* 404 Page */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </LoadingScreen>
    </Router>
  );
}
