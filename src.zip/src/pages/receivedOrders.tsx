import OrdersPage from './ordersPage'


export default function ReceivedOrders() {
    return (
        <div><OrdersPage filterStatus='Received' /></div>
    )
}