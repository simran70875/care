import { useCallback, useState } from "react";
import { Link, useLocation } from "react-router";
import {
  BoxCubeIcon,
  CalenderIcon,
  ChevronDownIcon,
  GridIcon,
  ListIcon,
  PageIcon,
  PieChartIcon,
  PlugInIcon,
  TableIcon,
  UserCircleIcon,
} from "../icons";
import { useSidebar } from "../context/SidebarContext";
import { clientSubMenu } from "../config/clientMenu";

export type NavItem = {
  name: string;
  icon?: React.ReactNode;
  path?: string;
  pro?: boolean;
  new?: boolean;
  subItems?: NavItem[];
};

// ----------------- MAIN MENU -----------------
const navItems: NavItem[] = [
  { icon: <GridIcon />, name: "Main Dashboard", path: "/" },
  {
    icon: <UserCircleIcon />,
    name: "Clients",
    path: "/customers/all",
    subItems: clientSubMenu,
  },
  { icon: <UserCircleIcon />, name: "Carers", path: "/carers" },
  { icon: <ListIcon />, name: "Notes", path: "/notes" },
  { icon: <CalenderIcon />, name: "Messages", path: "/messages" },
  { icon: <PageIcon />, name: "Noticeboard", path: "/noticeboard" },
  { icon: <PieChartIcon />, name: "Reports", path: "/reports" },
  { icon: <TableIcon />, name: "Finance", path: "/finance" },
  { icon: <BoxCubeIcon />, name: "Post-It", path: "/post-it" },
  { icon: <ListIcon />, name: "All Forms", path: "/all-forms" },
  { icon: <PageIcon />, name: "Custom Pages", path: "/custom-pages" },
  { icon: <CalenderIcon />, name: "Time Confirm", path: "/time-confirm" },
  { icon: <TableIcon />, name: "Filing Cabinet", path: "/filing-cabinet" },
  { icon: <BoxCubeIcon />, name: "PPE Unit Management", path: "/ppe-unit" },
  { icon: <GridIcon />, name: "Locations", path: "/locations" },
  { icon: <PlugInIcon />, name: "Company Settings", path: "/company-settings" },
];

// ----------------- OTHER SECTION -----------------
const othersItems: NavItem[] = [
  { icon: <PlugInIcon />, name: "Support Desk", path: "/support-desk" },
  { icon: <PlugInIcon />, name: "Help", path: "/help" },
];

const AppSidebar: React.FC = () => {
  const { isExpanded, isHovered, isMobileOpen, setIsHovered } = useSidebar();
  const location = useLocation();

  const [currentMenu, setCurrentMenu] = useState<NavItem[]>(navItems);
  const [currentLevel, setCurrentLevel] = useState<number>(0);

  // track dropdowns per item, not global
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>(
    {}
  );

  const isActive = useCallback(
    (path: string) => location.pathname === path,
    [location.pathname]
  );

  const handleMenuClick = (item: NavItem, level: number) => {
    if (item.name === "Main Dashboard") {
      // Reset sidebar to top-level menu
      setCurrentMenu(navItems);
      setCurrentLevel(0);
      return;
    }
    if (item.subItems && item.subItems.length > 0) {
      if (level === 0) {
        // 🧭 Drill to level 1
        setCurrentMenu(item.subItems);
        setCurrentLevel(1);
      } else {
        // 🪂 Level > 0 → dropdown toggle
        setOpenDropdowns((prev) => ({
          ...prev,
          [item.name]: !prev[item.name],
        }));
      }
    }
  };

  const renderMenu = (menu: NavItem[], level = 0) => {
    const combinedMenu =
      level === 0
        ? menu
        : [
            {
              icon: <GridIcon />,
              name: "Main Dashboard",
              path: "/",
              subItems: [],
            },
            ...menu,
          ];

    return (
      <ul
        className={`flex flex-col ${level === 0 ? "gap-2 p-4" : "ml-6 mt-2"}`}
      >
        {combinedMenu.map((item) => (
          <li key={item.name}>
            {item.subItems ? (
              <>
                <button
                  onClick={() => handleMenuClick(item, level)}
                  className="menu-item flex items-center w-full text-left"
                >
                  <span className="menu-item-icon-size">{item.icon}</span>
                  {(isExpanded || isHovered || isMobileOpen) && (
                    <span className="menu-item-text flex-1">{item.name}</span>
                  )}
                  <ChevronDownIcon
                    className={`w-4 h-4 transition-transform ${
                      openDropdowns[item.name] ? "rotate-180" : "rotate-0"
                    }`}
                  />
                </button>

                {/* Only show dropdowns for deeper levels */}
                {level > 0 && item.subItems && (
                  <div
                    className={`ml-8 mt-2 flex flex-col gap-2 transition-all duration-300 overflow-hidden ${
                      openDropdowns[item.name]
                        ? "max-h-[500px] opacity-100"
                        : "max-h-0 opacity-0"
                    }`}
                  >
                    {item.subItems.map((sub) => (
                      <Link
                        key={sub.name}
                        to={sub.path || ""}
                        className={`text-sm pl-3 py-1.5 rounded hover:bg-gray-100 dark:hover:bg-gray-800 ${
                          isActive(sub.path || "")
                            ? "text-brand-600 font-medium"
                            : "text-gray-600"
                        }`}
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <Link
                to={item.path || "#"}
                className={`menu-item ${
                  isActive(item.path || "") ? "menu-item-active" : ""
                }`}
              >
                <span className="menu-item-icon-size">{item.icon}</span>
                {(isExpanded || isHovered || isMobileOpen) && (
                  <span className="menu-item-text">{item.name}</span>
                )}
              </Link>
            )}
          </li>
        ))}
      </ul>
    );
  };

  return (
    <aside
      className={`fixed top-0 left-0 bg-white dark:bg-gray-900 h-screen border-r border-gray-200 z-50 transition-all duration-300
      ${isExpanded || isHovered || isMobileOpen ? "w-[290px]" : "w-[90px]"}`}
      onMouseEnter={() => !isExpanded && setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="p-6 border-b border-gray-200 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <img src="/images/logo/logo-icon.svg" alt="Logo" width={32} />
          {(isExpanded || isHovered || isMobileOpen) && (
            <span className="text-lg font-bold">WeCareChorlton</span>
          )}
        </Link>
      </div>

      {renderMenu(currentMenu, currentLevel)}
    </aside>
  );
};

export default AppSidebar;
